const suppliers = [
   {
      name: "Joe Schmo Appliances",
      address: "1000 Blue dr.",
      phone: "111-555-0000",
      email: "newguys@gmail.com",
      category: "Appliances",
      id: "1"

   },
   {
      name: "Billy's Tools WholeSale",
      address: "999 belk dr.",
      phone: "888-767-5555",
      email: "billtools@gmail.com",
      category: "Tools",
      id: "2"
   },
   {
      name: "TV Outpost",
      address: "500 Business Rd.",
      phone: "555-555-5555",
      email: "suppliers@tvoutpost.com",
      category: "Electronics",
      id: "3"
   },
   {
      name: "Circuits-R-Us",
      address: "500 Business Rd.",
      phone: "000-555-1111",
      email: "supply@circuitsrus.com",
      category: "Electronics",
      id: "4"

   },
   {
      name: "John Greere Tractors",
      address: "200 green dr.",
      phone: "909-000-0000",
      email: "runsgreere@gmail.com",
      category: "Outdoor Equipment",
      id: "5"
   },
   {
      name: "Dillon Supply",
      address: "1400 Bell Dr.",
      phone: "212-212-2121",
      email: "dillonsupply@dillonsupply.com",
      category: "Outdoor Equipment",
      id: "6"
   },
   {
      name: "G & S Supply Company",
      address: "1400 Bell Dr.",
      phone: "333-767-5555",
      email: "customersvc@gns.mail.com",
      category: "Appliances",
      id: "7"
   },
   {
      name: "RAM Tools Depot",
      address: "1400 Smith St.",
      phone: "111-322-8888",
      email: "ram@ramtools.com",
      category: "Tools",
      id: "8"
   },
   {
      name: "Kitchen Warehouse",
      address: "1400 Bell Dr.",
      phone: "777-097-5432",
      email: "kitchen@kitchewarehouse.com",
      category: "Appliances",
      id: "9"
   },

];

export default suppliers;
