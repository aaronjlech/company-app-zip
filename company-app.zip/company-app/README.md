#Packard's Outlet App README

##Packard's Outlet Supplier Directory App
###--Simple application using React w/ Redux

#Open the index.html file in the public folder to view application



#Use the following commands to run developer server
##To setup Execute in terminal:
```
npm install
```
##Start Dev Server
```
npm run go
```

#SERVER PORT
[localhost:3000](localhost:3000)

#Compile JS
```
npm run compile
```


[GitHub Repository](https://github.com/aaronjlech/Company-app)
